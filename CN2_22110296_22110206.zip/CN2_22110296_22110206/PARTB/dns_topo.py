#!/usr/bin/python3
"""
CS331 Assignment 2: DNS Query Resolution Topology
Author: [Your Name]
Date: [Current Date]
"""

from mininet.net import Mininet
from mininet.node import Host, OVSKernelSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.log import setLogLevel, info


# === Configuration ===
HOSTS = ['h1', 'h2', 'h3', 'h4']
HOST_IPS = {f'h{i}': f'10.0.0.{i}/24' for i in range(1, 5)}
DNS_IP = '10.0.0.5/24'
NAT_IP = '10.0.0.254/24'
GATEWAY = NAT_IP.split('/')[0]
SWITCHES = ['s1', 's2', 's3', 's4']
LINKS = [
    # (node1, node2, bw, delay)
    ('nat', 's1', None, None),
    ('h1', 's1', 100, '2ms'),
    ('h2', 's2', 100, '2ms'),
    ('h3', 's3', 100, '2ms'),
    ('h4', 's4', 100, '2ms'),
    ('dns', 's2', 100, '1ms'),
    ('s1', 's2', 100, '5ms'),
    ('s2', 's3', 100, '8ms'),
    ('s3', 's4', 100, '10ms'),
]


def create_network():
    """Initialize Mininet without controller (standalone switches)."""
    info('[INIT] Initializing Mininet network in standalone mode...\n')
    return Mininet(
        controller=None,
        switch=OVSKernelSwitch,
        host=Host,
        link=TCLink,
        autoSetMacs=True
    )


def add_all_hosts(net):
    """Add client hosts (h1-h4) and DNS resolver host."""
    info('[HOSTS] Deploying client hosts and DNS server...\n')
    nodes = {}
    for name, ip in HOST_IPS.items():
        nodes[name] = net.addHost(name, ip=ip)
        info(f'   → {name}: {ip}\n')
    nodes['dns'] = net.addHost('dns', ip=DNS_IP)
    info(f'   → dns: {DNS_IP}\n')
    return nodes


def add_all_switches(net):
    """Add four standalone switches."""
    info('[SWITCHES] Creating standalone switches s1 to s4...\n')
    switches = {}
    for name in SWITCHES:
        switches[name] = net.addSwitch(name, failMode='standalone')
        info(f'   → {name} (standalone)\n')
    return switches


def add_nat_gateway(net, switches):
    """Add NAT for external Internet access."""
    info('[NAT] Adding NAT gateway for Internet connectivity...\n')
    nat = net.addNAT(ip=NAT_IP, inNamespace=False)
    info(f'   → NAT: {NAT_IP} (connected to s1)\n')
    return nat


def add_all_links(net, nodes, switches, nat):
    """Add all links with bandwidth and delay."""
    info('[LINKS] Configuring network links with bandwidth and latency...\n')
    for src, dst, bw, delay in LINKS:
        node1 = nat if src == 'nat' else nodes.get(src, switches[src])
        node2 = nodes.get(dst, switches[dst])
        params = {}
        if bw: params['bw'] = bw
        if delay: params['delay'] = delay
        net.addLink(node1, node2, **params)
        info(f'   → {src} <-> {dst}  (bw={bw or "unlimited"}, delay={delay or "0ms"})\n')


def configure_routing(nodes):
    """Set default gateway on all hosts including dns."""
    info('[ROUTE] Configuring default gateway for all hosts...\n')
    for name, host in nodes.items():
        host.cmd(f'ip route add default via {GATEWAY}')
        info(f'   → {name}: default via {GATEWAY}\n')


def configure_part_b_dns(nodes):
    """Configure hosts to use public DNS (8.8.8.8) for Part B."""
    info('[DNS-B] Setting up public DNS resolution (Part B)...\n')
    for h in HOSTS:
        host = nodes[h]
        host.cmd('echo "nameserver 8.8.8.8" > /etc/resolv.conf')
        info(f'   → {h}: nameserver 8.8.8.8\n')


def run_topology():
    """Main orchestration: build, configure, and run the topology."""
    net = create_network()
    nodes = add_all_hosts(net)
    switches = add_all_switches(net)
    nat = add_nat_gateway(net, switches)
    add_all_links(net, nodes, switches, nat)

    info('[NETWORK] Starting Mininet emulation...\n')
    net.start()

    configure_routing(nodes)
    configure_part_b_dns(nodes)

    info('[INTERACTIVE] Entering Mininet CLI – type "exit" to stop.\n')
    info('   → Test with: h1 nslookup google.com\n')
    CLI(net)

    info('[SHUTDOWN] Terminating network and releasing resources...\n')
    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    run_topology()