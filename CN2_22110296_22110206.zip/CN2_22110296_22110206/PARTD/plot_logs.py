import sys
import pandas as pd
import matplotlib.pyplot as plt

# === Configuration ===
LOG_FILE = 'dns_log1.csv'
LATENCY_PLOT = 'D_latency_plot.png'
SERVERS_PLOT = 'D_servers_visited_plot.png'
MAX_QUERIES = 10
FIGURE_SIZE = (15, 7)


def load_data():
    """Load and validate CSV log file."""
    print(f"Attempting to read log file: {LOG_FILE}")
    try:
        df = pd.read_csv(LOG_FILE)
        if df.empty:
            print(f"ERROR: Log file '{LOG_FILE}' is empty.")
            sys.exit(1)
        return df
    except FileNotFoundError:
        print(f"ERROR: Log file not found at '{LOG_FILE}'")
        print("Please run the Mininet experiment first to generate the log.")
        sys.exit(1)
    except pd.errors.EmptyDataError:
        print(f"ERROR: Log file '{LOG_FILE}' is empty.")
        sys.exit(1)


def prepare_data(df):
    """Take first N queries and add index for plotting."""
    df_plot = df.head(MAX_QUERIES).copy()
    df_plot['query_index'] = range(len(df_plot))
    print(f"Loaded {len(df_plot)} queries for plotting.")
    return df_plot


def plot_latency(df_plot):
    """Create total resolution time bar chart."""
    plt.figure(figsize=FIGURE_SIZE)
    bars = plt.bar(
        df_plot['query_index'],
        df_plot['total_time_ms'],
        color='skyblue'
    )

    plt.xlabel('Domain Name', fontsize=12)
    plt.ylabel('Total Resolution Time (ms)', fontsize=12)
    plt.title('Total Resolution Latency per Query (First 10)', fontsize=16)
    plt.xticks(df_plot['query_index'], labels=df_plot['domain'], rotation=45, ha='right')

    # Annotate bars
    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height + 1,
            f'{height:.1f}',
            ha='center', va='bottom'
        )

    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(LATENCY_PLOT)
    print(f"Saved '{LATENCY_PLOT}'")


def plot_servers_visited(df_plot):
    """Create servers visited bar chart."""
    plt.figure(figsize=FIGURE_SIZE)
    bars = plt.bar(
        df_plot['query_index'],
        df_plot['servers_visited'],
        color='lightgreen'
    )

    plt.xlabel('Domain Name', fontsize=12)
    plt.ylabel('Number of DNS Servers Visited', fontsize=12)
    plt.title('Total DNS Servers Visited per Query (First 10)', fontsize=16)
    plt.xticks(df_plot['query_index'], labels=df_plot['domain'], rotation=45, ha='right')

    max_y = int(df_plot['servers_visited'].max()) + 1
    plt.yticks(range(0, max_y + 1))

    # Annotate bars
    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height,
            f'{int(height)}',
            ha='center', va='bottom', color='black', fontsize=10
        )

    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(SERVERS_PLOT)
    print(f"Saved '{SERVERS_PLOT}'")


def create_plots():
    """Main plotting pipeline."""
    df = load_data()
    df_plot = prepare_data(df)
    plot_latency(df_plot)
    plot_servers_visited(df_plot)
    print("\nPlotting complete! Check for 'D_latency_plot.png' and 'D_servers_visited_plot.png'.")


def main():
    print("Checking for plotting libraries (pandas, matplotlib)...")
    print("If this fails, run: sudo pip3 install pandas matplotlib")
    create_plots()


if __name__ == "__main__":
    main()