#!/usr/bin/python3
"""
CS331 Custom DNS Resolver - Part D (Logging Forwarder)
Improved wording in console output – same behaviour & CSV format.
"""

import socket
import socketserver
import datetime
import time
import os
import sys

# === Configuration ===
UPSTREAM_DNS_SERVER = "8.8.8.8"
UPSTREAM_DNS_PORT = 53
BIND_HOST = "10.0.0.5"
BIND_PORT = 53
LOG_FILE = "dns_log1.csv"

# DNS QTYPE mapping
QTYPE_MAP = {
    1: "A",
    28: "AAAA",
    5: "CNAME",
    15: "MX"
}


def initialize_log_file():
    """Create log file with header if not exists, or reset it."""
    header = "timestamp,domain,mode,server_ip,step,response,rtt_ms,total_time_ms,cache_status,servers_visited\n"
    try:
        if os.path.exists(LOG_FILE):
            os.remove(LOG_FILE)
        with open(LOG_FILE, "w") as f:
            f.write(header)
        print(f"[INFO] CSV log initialized: {LOG_FILE}")
    except Exception as e:
        print(f"[CRITICAL] Unable to create log file {LOG_FILE}: {e}")
        sys.exit(1)


def parse_dns_query(data):
    """Parse domain and QTYPE from DNS query packet (after header)."""
    try:
        i = 12
        labels = []
        while True:
            length = data[i]
            if length == 0:
                break
            i += 1
            label = data[i:i + length].decode('utf-8')
            labels.append(label)
            i += length

        domain = ".".join(labels)
        qtype_int = int.from_bytes(data[i + 1:i + 3], 'big')
        qtype_str = QTYPE_MAP.get(qtype_int, "UNKNOWN")
        return domain, f"{domain} ({qtype_str})"
    except Exception as e:
        print(f"[ERROR] Failed to parse domain name: {e}")
        return None, "UNKNOWN"


def log_query(entry):
    """Append a log entry to CSV."""
    line = (
        f"{entry['timestamp']},"
        f"{entry['domain_with_type']},"
        f"{entry['mode']},"
        f"{entry['server_ip']},"
        f"{entry['step']},"
        f"\"{entry['response']}\","
        f"{entry['rtt_ms']:.4f},"
        f"{entry['total_time_ms']:.4f},"
        f"{entry['cache_status']},"
        f"{entry['servers_visited']}\n"
    )
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line)
    except Exception as e:
        print(f"[ERROR] Could not write to CSV log: {e}")


class DNSRequestHandler(socketserver.BaseRequestHandler):

    def handle(self):
        data, client_sock = self.request
        client_addr = self.client_address

        # (a) Timestamp
        timestamp = datetime.datetime.now().isoformat()
        total_start = time.time()

        # (b) Parse domain and type
        domain, domain_with_type = parse_dns_query(data)
        if not domain:
            print("[WARN] Received malformed DNS query – discarding.")
            return

        print(f"\n{'='*15} NEW QUERY: {domain_with_type} {'='*15}")

        # Initialize log entry
        log_entry = {
            "timestamp": timestamp,
            "domain_with_type": domain_with_type,
            "mode": "Forwarding",
            "server_ip": UPSTREAM_DNS_SERVER,
            "step": "Forwarded",
            "response": "N/A",
            "rtt_ms": 0.0,
            "total_time_ms": 0.0,
            "cache_status": "N/A (No Cache)",
            "servers_visited": 1
        }

        # Forward to upstream
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as upstream_sock:
                upstream_sock.settimeout(2.0)
                rtt_start = time.time()

                print(f"[INFO] Forwarding query to upstream DNS {UPSTREAM_DNS_SERVER}:{UPSTREAM_DNS_PORT}")
                upstream_sock.sendto(data, (UPSTREAM_DNS_SERVER, UPSTREAM_DNS_PORT))
                response, _ = upstream_sock.recvfrom(512)

                rtt_ms = (time.time() - rtt_start) * 1000
                log_entry.update({
                    "rtt_ms": rtt_ms,
                    "response": "Response Received"
                })
                print(f"[SUCCESS] Upstream replied – RTT: {rtt_ms:.2f} ms")

                client_sock.sendto(response, client_addr)

        except socket.timeout:
            print("[TIMEOUT] No response from upstream within 2 seconds.")
            log_entry.update({
                "response": "Forwarding Timed Out",
                "rtt_ms": 2000.0
            })

        finally:
            total_ms = (time.time() - total_start) * 1000
            log_entry["total_time_ms"] = total_ms
            print(f"[INFO] Query completed in {total_ms:.2f} ms total.")
            log_query(log_entry)


def main():
    print(f"[STARTUP] DNS Forwarder listening on {BIND_HOST}:{BIND_PORT}")
    print(f"[CONFIG] All queries will be sent to upstream server {UPSTREAM_DNS_SERVER}")

    initialize_log_file()

    try:
        with socketserver.UDPServer((BIND_HOST, BIND_PORT), DNSRequestHandler) as server:
            server.serve_forever()
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Received interrupt – stopping server.")
    except Exception as e:
        print("="*60)
        print(f"[FATAL] Server failed to start: {e}")
        print("[HINT] Ensure you run with 'sudo' and that port 53 is free.")
        print("="*60)
        sys.exit(1)


if __name__ == "__main__":
    main()