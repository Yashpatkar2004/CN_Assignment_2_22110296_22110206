#!/usr/bin/python3
"""
CS331 Mininet Topology - Part C/D (Custom DNS Resolver)
Improved console wording – identical topology & behavior.
"""

from mininet.net import Mininet
from mininet.node import Host, OVSKernelSwitch
from mininet.link import TCLink
from mininet.cli import CLI
from mininet.log import setLogLevel, info


# === Configuration Constants ===
NETWORK = '10.0.0.0/24'
HOSTS = ['h1', 'h2', 'h3', 'h4']
HOST_IPS = {f'h{i+1}': f'10.0.0.{i+1}/24' for i in range(4)}
DNS_IP = '10.0.0.5/24'
NAT_IP = '10.0.0.254/24'
GATEWAY = NAT_IP.split('/')[0]
RESOLVER_SCRIPT = 'partd_custom_resolver.py'


def add_hosts(net):
    """Add h1-h4 and dns host."""
    info('[INFO] Creating client hosts (h1-h4) and DNS server host...\n')
    hosts = {}
    for name, ip in HOST_IPS.items():
        hosts[name] = net.addHost(name, ip=ip)
    hosts['dns'] = net.addHost('dns', ip=DNS_IP)
    return hosts


def add_switches(net):
    """Add s1-s4 switches."""
    info('[INFO] Deploying switches s1, s2, s3, s4...\n')
    return {f's{i}': net.addSwitch(f's{i}', failMode='standalone') for i in range(1, 5)}


def add_nat_and_connect(net, switches):
    """Add NAT and connect to s1."""
    info('[INFO] Adding NAT gateway for external Internet access...\n')
    nat = net.addNAT(ip=NAT_IP, inNamespace=False)
    net.addLink(nat, switches['s1'])
    return nat


def add_links(net, hosts, switches):
    """Add all host-switch and inter-switch links with BW/delay."""
    info('[CONFIG] Establishing links with bandwidth and latency...\n')

    # Host to switch
    net.addLink(hosts['h1'], switches['s1'], bw=100, delay='2ms')
    net.addLink(hosts['h2'], switches['s2'], bw=100, delay='2ms')
    net.addLink(hosts['h3'], switches['s3'], bw=100, delay='2ms')
    net.addLink(hosts['h4'], switches['s4'], bw=100, delay='2ms')
    net.addLink(hosts['dns'], switches['s2'], bw=100, delay='1ms')

    # Switch to switch
    net.addLink(switches['s1'], switches['s2'], bw=100, delay='5ms')
    net.addLink(switches['s2'], switches['s3'], bw=100, delay='8ms')
    net.addLink(switches['s3'], switches['s4'], bw=100, delay='10ms')


def configure_routing(net, hosts):
    """Set default gateway for all hosts including dns."""
    info('[CONFIG] Configuring default gateway on all hosts...\n')
    for name, host in hosts.items():
        host.cmd(f'ip route add default via {GATEWAY}')
        info(f'   → {name}: default via {GATEWAY}\n')


def configure_dns_clients(hosts):
    """Point h1-h4 to custom DNS resolver."""
    info('[CONFIG] Setting DNS resolver to 10.0.0.5 on client hosts...\n')
    for h in HOSTS:
        host = hosts[h]
        host.cmd(f'echo "nameserver 10.0.0.5" > /etc/resolv.conf')
        info(f'   → {h}: /etc/resolv.conf updated\n')


def start_dns_resolver(dns_host):
    """Launch Part D resolver in background."""
    info('[START] Launching Custom DNS Resolver (Part D) on dns host...\n')
    dns_host.cmd(f'sudo python3 {RESOLVER_SCRIPT} > /tmp/resolver.log 2>&1 &')
    info('   → Resolver started in background (log: /tmp/resolver.log)\n')


def create_topology():
    """Main function: build and run topology."""
    net = Mininet(
        switch=OVSKernelSwitch,
        host=Host,
        link=TCLink,
        autoSetMacs=True
    )

    hosts = add_hosts(net)
    switches = add_switches(net)
    add_nat_and_connect(net, switches)
    add_links(net, hosts, switches)

    info('[NETWORK] Starting Mininet network...\n')
    net.start()

    configure_routing(net, hosts)
    configure_dns_clients(hosts)
    start_dns_resolver(hosts['dns'])

    info('[INTERACTIVE] Entering Mininet CLI – type "exit" to stop.\n')
    CLI(net)

    info('[SHUTDOWN] Stopping network and cleaning up...\n')
    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    create_topology()