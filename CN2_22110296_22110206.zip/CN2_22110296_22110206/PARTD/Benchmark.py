
"""
DNS Benchmark Script - PCAP Edition
Usage: python3 benchmark.py <pcap_file.pcap>
"""

import sys
import subprocess
import time
import re
from collections import defaultdict
from scapy.all import rdpcap, DNS, DNSQR


# === Configuration ===
DIG_TIMEOUT = 5
DIG_CMD_TIMEOUT = 2  # +time=2 in dig
DIG_BASE_CMD = ['dig', '+stats', f'+time={DIG_CMD_TIMEOUT}']


def load_dns_queries(pcap_path):
    """Parse PCAP and extract unique DNS query domains."""
    unique_domains = set()
    query_count = 0

    try:
        packets = rdpcap(pcap_path)
        info(f'[PCAP] Loaded {len(packets)} packets from {pcap_path}')
    except FileNotFoundError:
        error(f'[ERROR] PCAP file not found: {pcap_path}')
        return []
    except Exception as e:
        error(f'[ERROR] Failed to read PCAP: {e}')
        return []

    info('[PCAP] Scanning for DNS queries...')
    for pkt in packets:
        if pkt.haslayer(DNS) and pkt.haslayer(DNSQR) and pkt[DNS].qr == 0:
            try:
                raw_name = pkt[DNSQR].qname
                domain = raw_name.decode('utf-8').rstrip('.')
                unique_domains.add(domain)
                query_count += 1
            except Exception:
                continue

    info(f'[PCAP] Found {query_count} DNS queries → {len(unique_domains)} unique domains')
    if not unique_domains:
        warn(f'[WARN] No valid DNS queries detected in {pcap_path}')
    return sorted(unique_domains)


def run_dns_benchmark(domains):
    """Benchmark DNS resolution using dig +stats in a single call."""
    if not domains:
        error('[BENCH] No domains to benchmark.')
        return

    results = []
    start_time = time.time()

    info(f'[BENCH] Starting benchmark for {len(domains)} domains...')
    for idx, domain in enumerate(domains, 1):
        try:
            cmd = DIG_BASE_CMD + [domain]
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=DIG_TIMEOUT
            )

            if proc.returncode == 0:
                match = re.search(r'Query time:\s*(\d+)\s*msec', proc.stdout)
                if match:
                    latency = int(match.group(1))
                    results.append(latency)
                    status = "SUCCESS"
                else:
                    status = "FAIL (no time)"
            else:
                status = "FAIL (dig error)"

        except subprocess.TimeoutExpired:
            status = "TIMEOUT"
        except Exception as e:
            status = f"EXCEPTION ({e})"

        # Progress indicator
        if idx % 10 == 0 or idx == len(domains):
            info(f'   → Processed {idx}/{len(domains)} domains')

    total_time = time.time() - start_time
    success = len(results)
    failed = len(domains) - success
    avg_latency = sum(results) / success if success else 0
    throughput = len(domains) / total_time if total_time > 0 else 0

    # === Final Results ===
    print("\n--- DNS Benchmark Results ---")
    print(f"Total Unique Queries: {len(domains)}")
    print(f"Successful:           {success}")
    print(f"Failed:               {failed}")
    print(f"Average Latency:      {avg_latency:.2f} ms")
    print(f"Average Throughput:   {throughput:.2f} queries/sec")


# === Logging Helpers ===
def info(msg):
    print(msg)

def warn(msg):
    print(msg, file=sys.stderr)

def error(msg):
    print(msg, file=sys.stderr)


# === Main ===
if __name__ == "__main__":
    if len(sys.argv) != 2:
        error(f"Usage: python3 {sys.argv[0]} <pcap_file.pcap>")
        sys.exit(1)

    pcap_file = sys.argv[1]
    info(f"[INPUT] Using PCAP: {pcap_file}")

    domains = load_dns_queries(pcap_file)
    if domains:
        run_dns_benchmark(domains)
    else:
        error("[ABORT] Benchmark terminated due to no valid domains.")