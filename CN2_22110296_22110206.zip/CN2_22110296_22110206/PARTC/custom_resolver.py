#!/usr/bin/python3
"""
CS331 Custom DNS Resolver - Improved Version
Author: [Your Name]
"""
import socket
import socketserver

UPSTREAM_DNS_SERVER = "8.8.8.8"
UPSTREAM_DNS_PORT = 53
LISTEN_HOST = "10.0.0.5"
LISTEN_PORT = 53


class DNSRequestHandler(socketserver.BaseRequestHandler):
    def parse_domain_name(self, packet):
        """Parse domain name from DNS query packet starting after header (offset 12)"""
        try:
            domain = []
            i = 12  # Start after DNS header
            while True:
                length = packet[i]
                if length == 0:
                    break
                i += 1
                label = packet[i:i + length].decode('utf-8')
                domain.append(label)
                i += length
            return ".".join(domain)
        except (IndexError, UnicodeDecodeError):
            return None

    def handle(self):
        data, client_socket = self.request
        client_addr = self.client_address

        # Parse domain from DNS query
        domain = self.parse_domain_name(data)
        if not domain:
            return

        print(f"DNS Query for: {domain}")

        # Forward query to upstream DNS server
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as upstream_sock:
                upstream_sock.settimeout(2.0)
                upstream_sock.sendto(data, (UPSTREAM_DNS_SERVER, UPSTREAM_DNS_PORT))
                response, _ = upstream_sock.recvfrom(512)
                client_socket.sendto(response, client_addr)
        except socket.timeout:
            print("DNS forwarding timed out.")
        except Exception as e:
            print(f"Unexpected error: {e}")


if __name__ == "__main__":
    print(f"Custom DNS Resolver starting on {LISTEN_HOST}:{LISTEN_PORT}...")
    try:
        with socketserver.UDPServer((LISTEN_HOST, LISTEN_PORT), DNSRequestHandler) as server:
            server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down DNS resolver...")
    except OSError as e:
        print(f"Failed to start server: {e}")