#!/usr/bin/python3
"""
CS331 Mininet Topology with Custom DNS Resolver
Author: [Your Name]
"""

from mininet.net import Mininet
from mininet.node import Host, OVSKernelSwitch, NAT
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.log import setLogLevel, info


def configure_hosts(net):
    """Configure IP routes and DNS settings for all hosts."""
    hosts = ['h1', 'h2', 'h3', 'h4']
    dns_ip = '10.0.0.5'
    gateway_ip = '10.0.0.254'

    info('[CONFIG] Applying default route and DNS configuration to client hosts...\n')
    for h in hosts:
        host = net.get(h)
        host.cmd(f'ip route add default via {gateway_ip}')
        host.cmd(f'echo "nameserver {dns_ip}" > /etc/resolv.conf')
        info(f'   → {h}: DNS set to {dns_ip}, gateway via {gateway_ip}\n')


def start_dns_resolver(dns_host):
    """Start the custom DNS resolver in background."""
    cmd = 'sudo python3 custom_resolver.py > /tmp/resolver.log 2>&1 &'
    dns_host.cmd(cmd)
    info('[START] Custom DNS Resolver launched on 10.0.0.5 (background)\n')
    info('   → Output redirected to /tmp/resolver.log\n')


def build_topology():
    """Create and configure the Mininet topology."""
    net = Mininet(
        switch=OVSKernelSwitch,
        host=Host,
        link=TCLink,
        autoSetMacs=True
    )

    info('[INFO] Creating hosts: h1-h4 (clients) and dns (resolver)...\n')
    h1 = net.addHost('h1', ip='10.0.0.1/24')
    h2 = net.addHost('h2', ip='10.0.0.2/24')
    h3 = net.addHost('h3', ip='10.0.0.3/24')
    h4 = net.addHost('h4', ip='10.0.0.4/24')
    dns = net.addHost('dns', ip='10.0.0.5/24')

    info('[INFO] Deploying switches: s1, s2, s3, s4 (standalone mode)...\n')
    s1 = net.addSwitch('s1', failMode='standalone')
    s2 = net.addSwitch('s2', failMode='standalone')
    s3 = net.addSwitch('s3', failMode='standalone')
    s4 = net.addSwitch('s4', failMode='standalone')

    info('[INFO] Adding NAT gateway for external Internet access...\n')
    nat = net.addNAT(ip='10.0.0.254/24').configDefault()

    info('[CONFIG] Establishing network links with bandwidth and latency...\n')
    # NAT to core switch
    net.addLink(nat, s1)

    # Host to switch links
    net.addLink(h1, s1, bw=100, delay='2ms')
    net.addLink(h2, s2, bw=100, delay='2ms')
    net.addLink(h3, s3, bw=100, delay='2ms')
    net.addLink(h4, s4, bw=100, delay='2ms')
    net.addLink(dns, s2, bw=100, delay='1ms')

    # Inter-switch links
    net.addLink(s1, s2, bw=100, delay='5ms')
    net.addLink(s2, s3, bw=100, delay='8ms')
    net.addLink(s3, s4, bw=100, delay='10ms')

    return net, dns


def create_topology():
    """Main function to build and run the topology."""
    net, dns_host = build_topology()

    info('[NETWORK] Starting Mininet network topology...\n')
    net.start()

    info('[CONFIG] Configuring routing and DNS for all hosts...\n')
    configure_hosts(net)

    info('[START] Initializing Custom DNS Resolver (Part D)...\n')
    start_dns_resolver(dns_host)

    info('[INTERACTIVE] Entering Mininet CLI – type "exit" to stop.\n')
    info('   → Use "h1 nslookup google.com" to test DNS resolution.\n')
    CLI(net)

    info('[SHUTDOWN] Stopping network and cleaning up resources...\n')
    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    create_topology()